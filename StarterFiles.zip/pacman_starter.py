import pygame, sys, random, time
from pygame.locals import K_a, K_d, K_w, K_s, QUIT
import os
pygame.init()

# Constants
WIDTH = 630
BOTTOM_BAR_HEIGHT = 50
HEIGHT = 726
TILES_WIDE = 30
TILES_HIGH  = 33
TILE_WIDTH = WIDTH // TILES_WIDE
TILE_HEIGHT = HEIGHT // TILES_HIGH
BLACK = (0,0,0)
RED = (255,0,0)
WHITE = (255,255,255)
CLOCK = pygame.time.Clock()
BOARD_COUNTER = 5
SPRITE_WIDTH = 30

# Board
# 0 = empty black rectangle, 1 = dot, 2 = big dot, 3 = vertical line,
# 4 = horizontal line, 5 = top right, 6 = top left, 7 = bot left, 8 = bot right
# 9 = gate 
board = [
[6, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5],
[3, 6, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 6, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 3],
[3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3],
[3, 3, 1, 6, 4, 4, 5, 1, 6, 4, 4, 4, 5, 1, 3, 3, 1, 6, 4, 4, 4, 5, 1, 6, 4, 4, 5, 1, 3, 3],
[3, 3, 2, 3, 0, 0, 3, 1, 3, 0, 0, 0, 3, 1, 3, 3, 1, 3, 0, 0, 0, 3, 1, 3, 0, 0, 3, 2, 3, 3],
[3, 3, 1, 7, 4, 4, 8, 1, 7, 4, 4, 4, 8, 1, 7, 8, 1, 7, 4, 4, 4, 8, 1, 7, 4, 4, 8, 1, 3, 3],
[3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3],
[3, 3, 1, 6, 4, 4, 5, 1, 6, 5, 1, 6, 4, 4, 4, 4, 4, 4, 5, 1, 6, 5, 1, 6, 4, 4, 5, 1, 3, 3],
[3, 3, 1, 7, 4, 4, 8, 1, 3, 3, 1, 7, 4, 4, 5, 6, 4, 4, 8, 1, 3, 3, 1, 7, 4, 4, 8, 1, 3, 3],
[3, 3, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 3, 3],
[3, 7, 4, 4, 4, 4, 5, 1, 3, 7, 4, 4, 5, 0, 3, 3, 0, 6, 4, 4, 8, 3, 1, 6, 4, 4, 4, 4, 8, 3],
[3, 0, 0, 0, 0, 0, 3, 1, 3, 6, 4, 4, 8, 0, 7, 8, 0, 7, 4, 4, 5, 3, 1, 3, 0, 0, 0, 0, 0, 3],
[3, 0, 0, 0, 0, 0, 3, 1, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 1, 3, 0, 0, 0, 0, 0, 3],
[8, 0, 0, 0, 0, 0, 3, 1, 3, 3, 0, 6, 4, 4, 9, 9, 4, 4, 5, 0, 3, 3, 1, 3, 0, 0, 0, 0, 0, 7],
[4, 4, 4, 4, 4, 4, 8, 1, 7, 8, 0, 3, 0, 0, 0, 0, 0, 0, 3, 0, 7, 8, 1, 7, 4, 4, 4, 4, 4, 4],
[0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
[4, 4, 4, 4, 4, 4, 5, 1, 6, 5, 0, 3, 0, 0, 0, 0, 0, 0, 3, 0, 6, 5, 1, 6, 4, 4, 4, 4, 4, 4],
[5, 0, 0, 0, 0, 0, 3, 1, 3, 3, 0, 7, 4, 4, 4, 4, 4, 4, 8, 0, 3, 3, 1, 3, 0, 0, 0, 0, 0, 6],
[3, 0, 0, 0, 0, 0, 3, 1, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 1, 3, 0, 0, 0, 0, 0, 3],
[3, 0, 0, 0, 0, 0, 3, 1, 3, 3, 0, 6, 4, 4, 4, 4, 4, 4, 5, 0, 3, 3, 1, 3, 0, 0, 0, 0, 0, 3],
[3, 6, 4, 4, 4, 4, 8, 1, 7, 8, 0, 7, 4, 4, 5, 6, 4, 4, 8, 0, 7, 8, 1, 7, 4, 4, 4, 4, 5, 3],
[3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3],
[3, 3, 1, 6, 4, 4, 5, 1, 6, 4, 4, 4, 5, 1, 3, 3, 1, 6, 4, 4, 4, 5, 1, 6, 4, 4, 5, 1, 3, 3],
[3, 3, 1, 7, 4, 5, 3, 1, 7, 4, 4, 4, 8, 1, 7, 8, 1, 7, 4, 4, 4, 8, 1, 3, 6, 4, 8, 1, 3, 3],
[3, 3, 2, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 2, 3, 3],
[3, 7, 4, 5, 1, 3, 3, 1, 6, 5, 1, 6, 4, 4, 4, 4, 4, 4, 5, 1, 6, 5, 1, 3, 3, 1, 6, 4, 8, 3],
[3, 6, 4, 8, 1, 7, 8, 1, 3, 3, 1, 7, 4, 4, 5, 6, 4, 4, 8, 1, 3, 3, 1, 7, 8, 1, 7, 4, 5, 3],
[3, 3, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 3, 3],
[3, 3, 1, 6, 4, 4, 4, 4, 8, 7, 4, 4, 5, 1, 3, 3, 1, 6, 4, 4, 8, 7, 4, 4, 4, 4, 5, 1, 3, 3],
[3, 3, 1, 7, 4, 4, 4, 4, 4, 4, 4, 4, 8, 1, 7, 8, 1, 7, 4, 4, 4, 4, 4, 4, 4, 4, 8, 1, 3, 3],
[3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3],
[3, 7, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8, 3],
[7, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8]
         ]

class Player:
    def __init__(self) -> None:
        self.width = SPRITE_WIDTH
        self.height = SPRITE_WIDTH
        path_to_image = os.path.join(os.path.dirname(__file__),"sprites","pacman","pacman.png")
        image = pygame.image.load(path_to_image).convert()
        self.img = pygame.transform.scale(image,size=(self.width,self.height))
        self.rect = pygame.Rect(0,0,self.width,self.height)
        self.rect.centerx = 15 * TILE_WIDTH
        self.rect.centery = (24 * TILE_HEIGHT) + 10
        self.speed = 5
        # direction = 0,1,2,3 corresponds to Left, Right, Up, Down
        self.direction = 1
        self.score = 0
        self.powered_up = False
        self.power_up_length = 7 # seconds
        self.power_up_timer = 0
        self.previous_time = 0
    
    def move(self):
       # TODO: Implement the movement of the player
       pass


    def draw(self,screen: pygame.Surface):
        # TODO: Implement the drawing of the player
        pass
    
    def actions(self, board):
        # TODO: Implement the actions of the player
        pass

    def die(self):
        print("DEAD")

    def eat_ghost(self):
        self.score += 200
   
def to_tile(x,y):
    return x // TILE_WIDTH, y //TILE_HEIGHT

def draw_board(screen: pygame.Surface, show_powerup):
    wall_colour = WHITE
    food_colour = WHITE
    wall_background = BLACK
    for row in range(TILES_HIGH):
        for col in range(TILES_WIDE):
            if board[row][col] == 0:
                pygame.draw.rect(screen,BLACK,
                                 pygame.Rect(col*TILE_WIDTH, row*TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
            elif board[row][col] == 1:
                radius = 2
                pygame.draw.rect(screen,BLACK,
                                 pygame.Rect(col*TILE_WIDTH, row*TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
                pygame.draw.circle(screen,food_colour,(col*TILE_WIDTH+TILE_WIDTH/2,row*TILE_HEIGHT+TILE_HEIGHT/2),radius)
            elif board[row][col] == 2 and show_powerup:
                radius = 8
                pygame.draw.circle(screen,food_colour,(col*TILE_WIDTH+TILE_WIDTH/2,row*TILE_HEIGHT+TILE_HEIGHT/2),radius)
            elif board[row][col] == 3:
                # Background
                pygame.draw.rect(screen,wall_background,
                                 pygame.Rect(col*TILE_WIDTH, row*TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
                # Foreground
                pygame.draw.rect(screen,wall_colour,
                                 pygame.Rect(col*TILE_WIDTH + (0.3 * TILE_WIDTH), row*TILE_HEIGHT, 0.4 * TILE_WIDTH, TILE_HEIGHT))
            elif board[row][col] == 4:
                # Background
                pygame.draw.rect(screen,wall_background,
                                 pygame.Rect(col*TILE_WIDTH, row*TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT))
                # Foreground
                pygame.draw.rect(screen,wall_colour,
                                 pygame.Rect(col*TILE_WIDTH, row*TILE_HEIGHT + (0.3 * TILE_HEIGHT), TILE_WIDTH, 0.4 * TILE_HEIGHT))
            # top right
            elif board[row][col] == 5:
                pygame.draw.rect(screen,wall_colour,
                                 pygame.Rect(col*TILE_WIDTH + (0.3 * TILE_WIDTH), row*TILE_HEIGHT + (0.3 * TILE_WIDTH),0.4*TILE_WIDTH,0.7*TILE_HEIGHT+1))
                pygame.draw.rect(screen,wall_colour,
                                 pygame.Rect(col*TILE_WIDTH, row*TILE_HEIGHT + (0.3 * TILE_WIDTH),0.7*TILE_WIDTH,0.4*TILE_HEIGHT))
            # top left
            elif board[row][col] == 6:
                pygame.draw.rect(screen,wall_colour,
                                 pygame.Rect(col*TILE_WIDTH + (0.3 * TILE_WIDTH), row*TILE_HEIGHT + (0.3 * TILE_WIDTH),0.4*TILE_WIDTH,0.7*TILE_HEIGHT+1))
                pygame.draw.rect(screen,wall_colour,
                                 pygame.Rect(col*TILE_WIDTH + (0.3 * TILE_WIDTH), row*TILE_HEIGHT + (0.3 * TILE_WIDTH),0.7*TILE_WIDTH+1,0.4*TILE_HEIGHT))
            # bottom left
            elif board[row][col] == 7:
                pygame.draw.rect(screen,wall_colour,
                                 pygame.Rect(col*TILE_WIDTH + (0.3 * TILE_WIDTH), row*TILE_HEIGHT-1, 0.4*TILE_WIDTH,0.7*TILE_HEIGHT))
                pygame.draw.rect(screen,wall_colour,
                                 pygame.Rect(col*TILE_WIDTH + (0.3 * TILE_WIDTH), row*TILE_HEIGHT + (0.3 * TILE_WIDTH),0.7*TILE_WIDTH+1,0.4*TILE_HEIGHT))
            # bottom right
            elif board[row][col] == 8:
                pygame.draw.rect(screen,wall_colour,
                                 pygame.Rect(col*TILE_WIDTH + (0.3 * TILE_WIDTH), row*TILE_HEIGHT-1,0.4*TILE_WIDTH,0.7*TILE_HEIGHT))
                pygame.draw.rect(screen,wall_colour,
                                 pygame.Rect(col*TILE_WIDTH, row*TILE_HEIGHT + (0.3 * TILE_WIDTH),0.7*TILE_WIDTH,0.4*TILE_HEIGHT))

def main():
    screen = pygame.display.set_mode((WIDTH,HEIGHT + BOTTOM_BAR_HEIGHT))
    player = Player()
    powerup_blink_interval = 0.1
    powerup_blink_timer = powerup_blink_interval
    show_powerup = True
    score_font_obj = pygame.font.SysFont("Consolas",18,bold=False)
    font_obj = pygame.font.SysFont("Consolas",36,bold=True)
    game_is_running = True
    time_delta = 0
    # TODO: Implement the game loop
main()